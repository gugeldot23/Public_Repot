from glob import glob   #To use glob caracters
from pikepdf import Pdf #To merge pdfs
from PIL import Image   #To convert images to pdfs
import os               #For removing files

USER = os.getlogin() 
path = "C:/Users/" + USER +"/Tools/PDF/"
output_file="output.pdf"
folder="Pdf_Drawer/"
valid_extensions = ("jpg","png","jpeg")
files_raw = []

def clean_pdf_folder (): #Removes all pdf folder subfiles
    for old_pdf_files in sorted(glob(path+folder+'*.pdf')):
        os.remove(old_pdf_files)

clean_pdf_folder()

#Selects valid files with valid extensions
for exts in valid_extensions: #Reads valid extensions and finds in directory files with that extension
    for files in sorted(glob(path+folder+'*.'+exts)):
        # print(files) 
        files_raw.append(files)

if len(files_raw) < 1: exit("ERROR: Not enough items") 

for converting in files_raw: #Converting images to pdfs
    name,extension = converting.split('.') 
    output_image = name +'.pdf'
    print("#", end = '') 
    # print(converting,output_image)
    image1 = Image.open(converting)
    im1 = image1.convert('RGB')
    im1.save(output_image)
else:
    print("\n")


pdf = Pdf.new()  #  Merging Pdfs part
for file in sorted(glob(path+folder+'*.pdf')):
    # print (file)
    src = Pdf.open(file)
    pdf.pages.extend(src.pages)
else:
    route = path + output_file 
    # print(route)
    pdf.save(route)
    print("Congrats! File at:",route)
    clean_pdf_folder()

#First complete written in 16/03/2021 00:45 by GreyNom
#Corrected to work with absolutes paths at 16/03/2021 01:35
#Corrected getting user in 02/06/2021 at 1:42 by GreyNom
